
import React, { Component } from 'react'
import PubSub from 'pubsub-js';
import axios from 'axios';

export default class index extends Component {
    search = () => {
        PubSub.publish('modify List state', { isFirst: false, isLoading: true })
        const { keyElement: { value: keyword } } = this;
        if (keyword.trim() === '') {
            window.confirm('输入不能为空')
        } else {
            axios.get(`http://localhost:3000/api1/search/users?q=${keyword}`).then(
                (response) => {
                    // console.log('请求成功',response.data);
                    PubSub.publish('modify List state', { isLoading: false, users: response.data.items })
                }
            ).catch(
                (error) => {
                    // console.log('请求失败',error);
                    PubSub.publish('modify List state',{ isLoading: false, err: error.message })
                }
            )
        }
    }
    render() {
        return (
            <section className="jumbotron">
                <h3 className="jumbotron-heading">Search Github Users</h3>
                <div>
                    <input ref={c => this.keyElement = c} type="text" placeholder="enter the name you search" />&nbsp;<button onClick={this.search}>Search</button>
                </div>
            </section>
        )
    }
}