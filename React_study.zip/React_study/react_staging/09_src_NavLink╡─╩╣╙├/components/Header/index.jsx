import React, { Component } from 'react'

export default class Header extends Component {
  render() {
    return (
        <div className="page-header"><h2>React Router Demo</h2></div>
    )
  }
}
