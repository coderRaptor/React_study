import React, { Component } from 'react';
import { NavLink,Route } from 'react-router-dom';
import About from './pages/About';
import Home from './pages/Home';
import Header from './components/Header';

/* 特别声明, 这项练习是在react-router-dom@5 的版本下的, 6版本进行了比较大的改动,用法已经改变 */
export default class App extends Component {
  render() {
    return (
      <div>
        <div className="row">
          <div className="col-xs-offset-2 col-xs-8">
            <Header></Header>
          </div>
        </div>
        <div className="row">
          <div className="col-xs-2 col-xs-offset-2">
            <div className="list-group">
              {/* 原生html中,靠<a>跳转不同的页面 */}
              {/* <a class="list-group-item active" href="./about.html">About</a> */}
              {/* <a class="list-group-item" href="./home.html">Home</a> */}

              {/* 在React中靠路由链接切换组件---编写路由链接 */}
              {/* <Link className="list-group-item" to='/about'>About</Link> */}
              {/* <Link className="list-group-item" to='/home'>home</Link> */}

              {/* Link高级版NavLink,可以有activeClassName属性,当此标签被点击时添加这个属性中的类名 */}
              {/* 此外当中activeClassName默认值为active,如果你也是用这个类名指定点击高亮,那么可以省略这个属性 */}
              <NavLink activeClassName="active" className="list-group-item" to='/about'>About</NavLink>
              <NavLink activeClassName="active" className="list-group-item" to='/home'>home</NavLink>
            </div>
          </div>
          <div className="col-xs-6">
            <div className="panel">
              <div className="panel-body">
                {/* 注册路由 */}
                <Route path="/about" component={About}></Route>
                <Route path="/home" component={Home}></Route>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }
}
