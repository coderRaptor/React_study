import React, { Component } from 'react'

export default class Test extends Component {
  render() {
    return (
      <h3>我是Test...</h3>
    )
  }
}
