import React, { Component } from 'react';
import { Route } from 'react-router-dom';
import About from './pages/About';
import Home from './pages/Home';
import Test from './pages/Test'
import Header from './components/Header';
import MyNavLink from './components/MyNavLink';
import { Switch } from 'react-router-dom/cjs/react-router-dom.min';

/* 特别声明, 这项练习是在react-router-dom@5 的版本下的, 6版本进行了比较大的改动,用法已经改变 */
export default class App extends Component {
  render() {
    return (
      <div>
        <div className="row">
          <div className="col-xs-offset-2 col-xs-8">
            <Header></Header>
          </div>
        </div>
        <div className="row">
          <div className="col-xs-2 col-xs-offset-2">
            <div className="list-group">
              {/* 原生html中,靠<a>跳转不同的页面 */}
              {/* <a class="list-group-item active" href="./about.html">About</a> */}
              {/* <a class="list-group-item" href="./home.html">Home</a> */}

              {/* 在React中靠路由链接切换组件---编写路由链接 */}
              {/* 封装自己的NavLink,就不用每次用NavLink都写className了,因为有时候导航栏每个导航按钮样式都一样 */}
              <MyNavLink to="/atguigu/about">About</MyNavLink>
              <MyNavLink to="/atguigu/home">Home</MyNavLink>
            </div>
          </div>
          <div className="col-xs-6">
            <div className="panel">
              <div className="panel-body">
                {/* 注册路由 */}
                {/* Switch实现单一匹配,只匹配一个, 这里Test在Home之前,path都是/home, 所以匹配Test */}
                {/* 如果不用Switch包裹则会匹配所有,即如果path是/home, 那么Test和Home都会展示 */}
                <Switch>
                  <Route path="/atguigu/about" component={About}></Route>
                  <Route path="/atguigu/home" component={Test}></Route>
                  <Route path="/atguigu/home" component={Home}></Route>
                </Switch>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }
}
