import React, { Component } from 'react';
import { Route } from 'react-router-dom';
import About from './pages/About';
import Home from './pages/Home';
import Test from './pages/Test'
import Header from './components/Header';
import MyNavLink from './components/MyNavLink';
import { Switch } from 'react-router-dom/cjs/react-router-dom.min';

/* 特别声明, 这项练习是在react-router-dom@5 的版本下的, 6版本进行了比较大的改动,用法已经改变 */
export default class App extends Component {
  render() {
    return (
      <div>
        <div className="row">
          <div className="col-xs-offset-2 col-xs-8">
            <Header></Header>
          </div>
        </div>
        <div className="row">
          <div className="col-xs-2 col-xs-offset-2">
            <div className="list-group">
              {/* 原生html中,靠<a>跳转不同的页面 */}
              {/* <a class="list-group-item active" href="./about.html">About</a> */}
              {/* <a class="list-group-item" href="./home.html">Home</a> */}

              {/* 在React中靠路由链接切换组件---编写路由链接 */}
              <MyNavLink to="/about">About</MyNavLink>
              <MyNavLink to="/home/a/b">Home</MyNavLink>
              {/* 因为如果./开头,那么在BrowserRouter模式下地址栏是没有#拼接,直接/拼接,那么当你刷新或强刷不走缓存时,由于./是相对自身路径出发,那么重新请求引入的样式时默认以当前地址栏地址出发,那么就会把路由匹配那些混入进来,导致请求样式失败重定向为没有样式的index.html,但是用HashRouter模式就有#隔开, 请求规则中#以及其后面的都不会作为请求地址的一部分发送请求,所以没有这个问题, 但是有个#不好看,所以大多数采取BrowserRouter模式, 然后index.html中请求样式不要用./
                  解决方案如下:
                    1.public/index.html 中 引入样式时不写 ./ 写 / （常用,代表根路径,是绝对路径,而在脚手架里public刚好是根路径,此外,/开头在任何地方(哪怕不是前端框架里)它都是指根路径）
                    2.public/index.html 中 引入样式时不写 ./ 写 %PUBLIC_URL% （常用, 代表public,在React脚手架下起作用, 可能其他前端框架脚手架里也是定义%PUBLIC_URL%为public）
                    3.使用HashRouter */}
            </div>
          </div>
          <div className="col-xs-6">
            <div className="panel">
              <div className="panel-body">
                {/* 注册路由 */}
                {/* 默认模糊匹配,想要精准要开启,但开启后容易导致多级路由匹配出问题，这里学的5, 现在路由版本为6, 变更很大 */}
                <Switch>
                  <Route exact path="/about" component={About}></Route>
                  <Route exact path="/home" component={Test}></Route>
                  <Route exact path="/home" component={Home}></Route>
                </Switch>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }
}
