
import React, { Component } from 'react'
import PubSub from 'pubsub-js';
// import axios from 'axios';

export default class index extends Component {
    search = async () => {
        PubSub.publish('modify List state', { isFirst: false, isLoading: true })
        const { keyElement: { value: keyword } } = this;
        if (keyword.trim() === '') {
            window.confirm('输入不能为空')
        } else {
            /* axios.get(`http://api.github.com/search/users?q=${keyword}`).then(
                (response) => {
                    // console.log('请求成功',response.data);
                    PubSub.publish('modify List state', { isLoading: false, users: response.data.items })
                }
            ).catch(
                (error) => {
                    // console.log('请求失败',error);
                    PubSub.publish('modify List state',{ isLoading: false, err: error.message })
                }
            ) */
            // 未优化fetch fetch即可get也可post, 下面是get所以fetch()中省略了第二个配置对象参数
            // fetch也可以实现ajax异步请求,它是原生的,并非借助XMLHttpRequest, 但旧版浏览器不支持
            // axios与jquery都是借助XMLHttpRequest对象, 也就是对xhr的封装
            // axios和fetch都是Promise风格, jquery不是,所以jquery有回调地狱问题
            /* fetch(`http://api.github.com/search/users?q=${keyword}`)
            .then(
                response => {
                    console.log('联系服务器成功!', response);
                    // 调用response.json()把数据取出来
                    // 这里会把返回值包装为成功状态的Promise对象, 成功值为返回值
                    // 如果是返回异常则默认包装成失败状态的Promise, 失败值为返回的异常
                    return response.json();
                }
            )
            .then(
                data => {console.log('数据拿到了', data)}
            )
            .catch(
                error => console.log('请求失败',error)
            ) */

            // 优化后fetch,记得给search函数加上async,await必须在async修饰的函数中使用
            try {
                const response = await fetch(`http://api.github.com/search/users?q=${keyword}`);
                const data = await response.json();
                PubSub.publish('modify List state', { isLoading: false, users: data.items })
            } catch (error) {
                console.log('请求失败', error);
                PubSub.publish('modify List state', { isLoading: false, err: error.message })
            }
        }
    }
    render() {
        return (
            <section className="jumbotron">
                <h3 className="jumbotron-heading">Search Github Users</h3>
                <div>
                    <input ref={c => this.keyElement = c} type="text" placeholder="enter the name you search" />&nbsp;<button onClick={this.search}>Search</button>
                </div>
            </section>
        )
    }
}