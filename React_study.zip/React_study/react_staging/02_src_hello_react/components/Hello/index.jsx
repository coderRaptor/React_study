import hello from './index.module.css';
export default function Hello(){
    return (
        <h2 className={hello.title}>你好, React!</h2>
    )
}