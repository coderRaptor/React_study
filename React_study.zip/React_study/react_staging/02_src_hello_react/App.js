// 引入App组件的样式文件, css后缀不能省略, 在react脚手架环境只有js和jsx可以省略
import './App.css';
// 引入Hello组件
import Hello from './components/Hello'
// 引入Welcome组件
import Welcome from './components/Welcome'
// 定义App组件
function App() {
  return (
    <div className="App">
      <Hello/>
      <Welcome/>
    </div>
  );
}

// 暴露(导出)App组件
export default App;
