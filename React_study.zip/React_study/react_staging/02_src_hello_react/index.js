// 引入react核心库
import React from 'react';
// 引入react-dom
import ReactDOM from 'react-dom/client';
// 引入全局样式
import './index.css';
// 引入应用外壳组件App组件
import App from './App';


// React 将会为 domNode 创建一个根节点，并控制其中的 DOM。在已经创建根节点之后，需要调用 root.render 来渲染 React 组件
// 又或者说将 domNode 作为容器根节点, 把React组件挂载到该根节点上
const root = ReactDOM.createRoot(document.getElementById('root'));
// 调用render渲染函数
// 调用 root.render 以将一段 JSX（“React 节点”）在 React 的根节点中渲染 DOM 节点并显示。
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);


