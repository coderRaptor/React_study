import React, { Component } from 'react'
import { Link, Route } from 'react-router-dom/cjs/react-router-dom.min';
import Detail from './Detail';

export default class Message extends Component {
    state = {
        msgArr: [
            {id:'01', title:'消息01'},
            {id:'02', title:'消息02'},
            {id:'03', title:'消息03'},
        ]
    }
  render() {
    const {msgArr} = this.state;
    return (
        <div>
            <ul>
                {
                    msgArr.map((msgObj) => {
                        return (
                            <li key={msgObj.id}>
                                {/* 向路由组件传递params参数 */}
                                <Link to={`/home/message/Detail/${msgObj.id}/${msgObj.title}`}>{msgObj.title}</Link>
                            </li>
                        )
                    })
                }
            </ul>
            <Route path="/home/message/Detail/:id/:title" component={Detail} />
        </div>
    )
  }
}
