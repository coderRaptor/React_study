import React, { Component } from 'react'

const DetailData = [
    {id:'01', content:"你好未来的自己"},
    {id:'02', content:"React"},
    {id:'03', content:"Vue"},
]
export default class Detail extends Component {
  render() {
    console.log(this.props);
    // 接收params参数
    const {id,title} = this.props.match.params;
    const {content} = DetailData.find((detailObj) => {
        return detailObj.id === id;
    })
    return (
        <div>
            <hr />
            <ul>
                <li>ID:{id}</li>
                <li>TITLE:{title}</li>
                <li>CONTENT:{content}</li>
            </ul>
        </div>
    )
  }
}
