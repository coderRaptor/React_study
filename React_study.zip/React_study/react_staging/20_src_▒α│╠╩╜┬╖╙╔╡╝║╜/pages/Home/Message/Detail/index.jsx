import React, { Component } from 'react'
// import qs from 'qs';

const DetailData = [
    {id:'01', content:"你好1"},
    {id:'02', content:"你好2"},
    {id:'03', content:"你好3"},
]
export default class Detail extends Component {
  render() {
    console.log(this.props);
    // 接收params参数
    // 参数在地址栏上,用户收藏地址清空缓存后再访问或用该地址在新页面访问也没啥,因为参数在地址上
    const {id,title} = this.props.match.params;

    // 接收search参数
    // 参数在地址栏上,用户收藏地址清空缓存后再访问或用该地址在新页面访问也没啥,因为参数在地址上
    // const {search} = this.props.location;
    // const {id, title} = qs.parse(search.slice(1));

    // 接收state参数
    // 参数不在地址栏上,在当前页面缓存里, 但刷新也可以保留住参数, 如果清空浏览器缓存或在新页面打开该地址参数将消失
    // 所以用state参数要注意用户收藏地址后清空浏览器缓存又点击该地址或者用该地址在新页面打开导致state为undefined,要用个 {} 兜底
    // const {id, title} = this.props.location.state || {};

    const {content} = DetailData.find((detailObj) => {
        return detailObj.id === id;
    }) || {}
    return (
        <div>
            <hr />
            <ul>
                <li>ID:{id}</li>
                <li>TITLE:{title}</li>
                <li>CONTENT:{content}</li>
            </ul>
        </div>
    )
  }
}
