## 一、todoList案例相关知识点
		1.拆分组件、实现静态组件，注意：className、style的写法
		2.动态初始化列表，如何确定将数据放在哪个组件的state中？
					——某个组件使用：放在其自身的state中
					——某些组件使用：放在他们共同的父组件state中（官方称此操作为：状态提升）
		3.关于父子之间通信：
				1.【父组件】给【子组件】传递数据：通过props传递
				2.【子组件】给【父组件】传递数据：通过props传递，要求父提前给子传递一个函数
		4.注意defaultChecked 和 checked的区别，类似的还有：defaultValue 和 value
		5.状态在哪里，操作状态的方法就在哪里

## 二、github搜索案例相关知识点
		1.设计状态时要考虑全面，例如带有网络请求的组件，要考虑请求失败怎么办。
		2.ES6小知识点：解构赋值+重命名
					let obj = {a:{b:1}}
					const {a} = obj; //传统解构赋值
					const {a:{b}} = obj; //连续解构赋值
					const {a:{b:value}} = obj; //连续解构赋值+重命名
		3.消息订阅与发布机制
					1.先订阅，再发布（理解：有一种隔空对话的感觉）
					2.适用于任意组件间通信
					3.要在组件的componentWillUnmount中取消订阅
		4.fetch发送请求（关注分离的设计思想）
					try {
						const response= await fetch(`/api1/search/users2?q=${keyWord}`)
						const data = await response.json()
						console.log(data);
					} catch (error) {
						console.log('请求出错',error);
					}


## 三、路由的基本使用
			1.明确好界面中的导航区、展示区
			2.导航区的a标签改为Link标签
						<Link to="/xxxxx">Demo</Link>
			3.展示区写Route标签进行路径的匹配
						<Route path='/xxxx' component={Demo}/>
			4.<App>的最外侧包裹了一个<BrowserRouter>或<HashRouter>

## 四、路由组件与一般组件
			1.写法不同：
						一般组件：<Demo/>
						路由组件：<Route path="/demo" component={Demo}/>
			2.存放位置不同：
						一般组件：components
						路由组件：pages
			3.接收到的props不同：
						一般组件：写组件标签时传递了什么，就能收到什么
						路由组件：接收到三个固定的属性(只是写了开发用到的,底层用的没写在这)
											history:
														go: ƒ go(n)
														goBack: ƒ goBack()
														goForward: ƒ goForward()
														push: ƒ push(path, state)
														replace: ƒ replace(path, state)
														location
											location:
														pathname: "/about"
														search: ""
														state: undefined
											match:
														params: {}
														path: "/about"
														url: "/about"
						备注：location本质是在history中的，与history同级的location只是从history里面提出来的引用，以便于操作。

## 五、NavLink与封装NavLink
				1.NavLink可以实现路由链接的高亮，通过activeClassName指定样式名, 不写该属性则默认activeClassName="active", 					如果你的样式点击高亮的类名也叫active,你可以不写就生效了。
				2.标签体内容是一个特殊的标签属性
				3.通过this.props.children可以获取标签体内容

## 六、Switch的使用
				1.通常情况下，path和component是一一对应的关系。
				2.Switch可以提高路由匹配效率(单一匹配)。

## 七、解决多级路径刷新页面样式丢失的问题
			因为如果./开头,那么在BrowserRouter模式下地址栏是没有#拼接,直接/拼接,那么当你刷新或强刷不走缓存时,由于./是相对自身路径出发,那么重新请求引入的样式时默认以当前地址栏地址出发,那么就会把路由匹配那些混入进来,导致请求样式失败重定向为没有样式的index.html,但是用HashRouter模式就有#隔开, 请求规则中#以及其后面的都不会作为请求地址的一部分发送请求,所以没有这个问题, 但是有个#不好看,所以大多数采取BrowserRouter模式, 然后index.html中请求样式不要用./
			解决方案如下:
				1.public/index.html 中 引入样式时不写 ./ 写 / （常用,代表根路径,是绝对路径,而在脚手架里public刚好是根路径,此外,/开头在任何地方(哪怕不是前端框架里)它都是指根路径）
				2.public/index.html 中 引入样式时不写 ./ 写 %PUBLIC_URL% （常用, 代表public,在React脚手架下起作用, 可能其他前端框架脚手架里也是定义%PUBLIC_URL%为public）
				3.使用HashRouter

## 八、路由的严格匹配与模糊匹配
				1.默认使用的是模糊匹配（简单记：【输入的路径】必须包含要【匹配的路径】，且顺序要一致）
				2.开启严格匹配：<Route exact={true} path="/about" component={About}/>
				3.严格匹配不要随便开启，需要再开，有些时候开启会导致无法继续匹配二级路由

## 九、Redirect的使用	
				1.一般写在所有路由注册的最下方，当所有路由都无法匹配时，跳转到Redirect指定的路由
				2.具体编码：
						<Switch>
							<Route path="/about" component={About}/>
							<Route path="/home" component={Home}/>
							<Redirect to="/about"/>
						</Switch>

## 十、嵌套路由
				1.注册子路由时要写上父路由的path值
				2.路由的匹配是按照注册路由的顺序进行的

## 十一、向路由组件传递参数
				1.params参数
							路由链接(携带参数)：<Link to='/demo/test/tom/18'}>详情</Link>
							注册路由(声明接收)：<Route path="/demo/test/:name/:age" component={Test}/>
							接收参数：this.props.match.params
							备注: 参数在地址栏上,用户收藏地址清空历史记录缓存后再访问或用该地址在新页面访问也没啥,因为参数在地址上
				2.search参数
							路由链接(携带参数)：<Link to='/demo/test?name=tom&age=18'}>详情</Link>
							注册路由(无需声明，正常注册即可)：<Route path="/demo/test" component={Test}/>
							接收参数：this.props.location.search
							备注：获取到的search是urlencoded编码字符串，需要借助querystring或自带的qs解析
								参数在地址栏上,用户收藏地址清空历史记录缓存后再访问或用该地址在新页面访问也没啥,因为参数在地址上
				3.state参数
							路由链接(携带参数)：<Link to={{pathname:'/demo/test',state:{name:'tom',age:18}}}>详情</Link>
							注册路由(无需声明，正常注册即可)：<Route path="/demo/test" component={Test}/>
							接收参数：this.props.location.state
							备注：参数不在地址栏上,在当前页面缓存里, 但刷新也可以保留住参数, 如果清空浏览器缓存或在新页面打开该地址参数将消失
									所以用state参数要注意用户收藏地址后清空浏览器历史记录缓存又点击该地址或者用该地址在新页面打开导致state为undefined,要用个 {} 兜底



## 十二、编程式路由导航
					借助this.prosp.history对象上的API对操作路由跳转、前进、后退
							-this.prosp.history.push()
							-this.prosp.history.replace()
							-this.prosp.history.goBack()
							-this.prosp.history.goForward()
							-this.prosp.history.go()

## 十三、BrowserRouter与HashRouter的区别
			1.底层原理不一样：
						BrowserRouter使用的是H5的history API，不兼容IE9及以下版本。
						HashRouter使用的是URL的哈希值。
			2.path表现形式不一样
						BrowserRouter的路径中没有#,例如：localhost:3000/demo/test
						HashRouter的路径包含#,例如：localhost:3000/#/demo/test
			3.刷新后对路由state参数的影响
						(1).BrowserRouter没有任何影响，因为state保存在当前页面历史记录即history对象中, 而如同 十一 笔记而言, 清空历史记录或新开页面都会导致state丢失, 
						(2).HashRouter刷新后会导致路由state参数的丢失！！！因为底层原理不一样, HashRouter底层用的是 URL 的哈希值, 而 state 是保存在 history 中的
			4.备注：HashRouter可以用于解决一些路径错误相关的问题, 如之前笔记 七 提到的样式丢失问题。

## 十四、antd的按需引入+自定主题
			1.安装依赖：yarn add react-app-rewired customize-cra babel-plugin-import less less-loader
			2.修改package.json
					....
						"scripts": {
							"start": "react-app-rewired start",
							"build": "react-app-rewired build",
							"test": "react-app-rewired test",
							"eject": "react-scripts eject"
						},
					....
			3.根目录下创建config-overrides.js
					//配置具体的修改规则
					const { override, fixBabelImports,addLessLoader} = require('customize-cra');
					module.exports = override(
						fixBabelImports('import', {
							libraryName: 'antd',
							libraryDirectory: 'es',
							style: true,
						}),
						addLessLoader({
							lessOptions:{
								javascriptEnabled: true,
								modifyVars: { '@primary-color': 'green' },
							}
						}),
					);
				4.备注：不用在组件里亲自引入样式了，即：import 'antd/dist/antd.css'应该删掉