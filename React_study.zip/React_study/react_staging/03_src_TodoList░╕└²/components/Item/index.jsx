import React, { Component } from 'react'
import './index.css';

export default class Item extends Component {
  state = {
    mouse: false, //标识鼠标移入移出
  }
  handleMouse = (flag) => {
    return () => {
      this.setState({ mouse: flag })
    }
  }
  handleCheck = () => {
    const { id, changeTodo } = this.props;
    changeTodo(id);
  }
  handleDelete = () => {
    const {id, deleteTodo} = this.props;
    deleteTodo(id);
  }
  
  render() {
    const { handleCheck, handleDelete } = this;
    const { name, done } = this.props;
    const { mouse } = this.state;
    // defaultChecked 只有初次渲染时有效, 后续失效, 和名字一样意思, 初始化渲染默认选择, 后续更新该属性失效,不起作用
    // 写checked时必须写 onChange事件否则报错说: 需要一个onChange来改变选择状态,否则checked的值就是死数据,变不了
    return (
      <li style={{ backgroundColor: mouse ? '#ddd' : 'white' }} onMouseEnter={this.handleMouse(true)} onMouseLeave={this.handleMouse(false)}>
        <label>
          <input type="checkbox" checked={done} onChange={handleCheck} />
          <span>{name}</span>
        </label>
        <button onClick={handleDelete} className="btn btn-danger" style={{ display: mouse ? 'block' : 'none' }}>删除</button>
      </li>
    )
  }
}
