import React, { Component } from 'react';
import Header from './components/Header';
import List from './components/List';
import Footer from './components/Footer';
import './App.css';

// 定义App组件
class App extends Component {
  state = {
    todos: [
      { id: '001', name: '吃饭', done: true },
      { id: '002', name: '睡觉', done: true },
      { id: '003', name: '打代码', done: false },
      { id: '004', name: '逛街', done: true },
    ]
  }
  addTodo = (todoObj) => {
    const { todos } = this.state;
    const newTodos = [todoObj, ...todos];
    this.setState({ todos: newTodos });

  }
  changeTodo = (id) => {
    const newTodos = this.state.todos.map((todoObj) => {
      if(todoObj.id === id){
        // 方式一
        // todoObj.done = !todoObj.done;
        // 方式二 此api将后续参数对象合并到第一个参数对象中,改变了第一个参数对象
        // Object.assign(todoObj,{done:!todoObj.done})
      }
      // return todoObj;

      // 方式二
      return todoObj.id === id ? { ...todoObj, done: !todoObj.done } : todoObj;
    })
    this.setState({ todos: newTodos })
  }
  deleteTodo = (id) => {
    const { todos } = this.state;
    const newTodos = todos.filter((todoObj) => {
      return todoObj.id !== id;
    })
    this.setState({ todos: newTodos });
  }
  checkAll = (done) => {
    const {todos} = this.state;
    const newTodos = todos.map((todoObj) => {
      return {...todoObj, done}
    })
    this.setState({todos:newTodos});
  }
  clearAllDone = () => {
   const {todos} = this.state;
   const newTodos = todos.filter(todoObj => !todoObj.done);
   this.setState({todos:newTodos}); 
  }
  render() {
    const { todos } = this.state;
    const { addTodo, changeTodo, deleteTodo, checkAll, clearAllDone } = this;
    return (
      <div className="todo-container">
        <div className="todo-wrap">
          <Header addTodo={addTodo} />
          <List todos={todos} changeTodo={changeTodo} deleteTodo={deleteTodo} />
          <Footer todos={todos} checkAll={checkAll} clearAllDone={clearAllDone} />
        </div>
      </div>
    );
  }
}

// 暴露(导出)App组件
export default App;
