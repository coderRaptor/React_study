import React, { Component } from 'react';
import { Button } from 'antd';

/* 特别声明, 这项练习是在react-router-dom@5 的版本下的, 6版本进行了比较大的改动,用法已经改变 */
export default class App extends Component {
  render() {
    return (
      <div>
        <Button type="primary">Primary Button</Button>
      </div>
    )
  }
}
