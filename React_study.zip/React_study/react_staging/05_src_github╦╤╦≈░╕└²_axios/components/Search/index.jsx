
import React, { Component } from 'react'
import axios from 'axios';

export default class index extends Component {
    search = () => {
        this.props.updateState({ isFirst: false, isLoading: true });
        const { keyElement: { value: keyword } } = this;
        if (keyword.trim() === '') {
            window.confirm('输入不能为空')
        } else {
            axios.get(`https://api.github.com/search/users?q=${keyword}`).then(
                (response) => {
                    // console.log('请求成功',response.data);
                    this.props.updateState({ isLoading: false, users: response.data.items });
                }
            ).catch(
                (error) => {
                    // console.log('请求失败',error);
                    this.props.updateState({ isLoading: false, err: error.message })
                }
            )
        }
    }
    render() {
        return (
            <section className="jumbotron">
                <h3 className="jumbotron-heading">Search Github Users</h3>
                <div>
                    <input ref={c => this.keyElement = c} type="text" placeholder="enter the name you search" />&nbsp;<button onClick={this.search}>Search</button>
                </div>
            </section>
        )
    }
}