import React, { createContext, useContext } from 'react'
import './index.css'

const SomeContext = createContext()
export default function A() {
    const [username] = React.useState('jack')
    const [age] = React.useState(18)
    return (
        <div className="parent">
            <h3>我是A组件</h3>
            <h4>我的用户名是:{username}</h4>
            <SomeContext.Provider value={{ age, username }}>
                <B />
            </SomeContext.Provider>
        </div>
    )
}

function B() {
    return (
        <div className='child'>
            <h3>我是B组件</h3>
            <h4>我从A中接收的用户名是:{ }</h4>
            <C />
        </div>
    )
}
function C() {
    const context = useContext(SomeContext);
    console.log(context);
    return (
        <div className='grand'>
            <h3>我是C组件</h3>
            <h4>我从A中接收的用户名是:{context.username}, 年龄为: {context.age}</h4>
        </div>
    )
}
