import React, { Component } from 'react'
import Child from './Child'

export default class Parent extends Component {
    state = {
        hasError:false,//用于标识子组件是否产生错误
        msg:"2434"
    }
    // 当Parent的子组件出现报错时候, 会触发getDerivedStateFromError
    // 不让子组件的错误导致整个页面红屏, 让错误信息限制在子组件的展示范围
    static getDerivedStateFromError(error){
        console.log(error)
        return {hasError: true}
    }

    componentDidCatch(error, info){
        console.log('统计错误此处, 发送给后台通知人员进行bug修复')
        console.log(error, info)
    }
  render() {
    // console.log(this.state)
    return (
      <div>
        <h2>我是Parent组件</h2>
        {this.state.hasError ? <h2>当前网络不稳定,请稍后再试</h2> : <Child/>}
      </div>
    )
  }
}
