import React, { Component, lazy, Suspense } from 'react';
import { NavLink, Route } from 'react-router-dom';

// import About from './About';
// import Home from './Home';

import Loading from './Loading';
const About = lazy(()=>import('./About'));
const Home = lazy(()=>import('./Home'));

/* 特别声明, 这项练习是在react-router-dom@5 的版本下的, 6版本进行了比较大的改动,用法已经改变 */
export default class Demo extends Component {
  render() {
    return (
      <div>
        <div className="row">
          <div className="col-xs-offset-2 col-xs-8">
            <div className="page-header"><h2>React Router Demo</h2></div>
          </div>
        </div>
        <div className="row">
          <div className="col-xs-2 col-xs-offset-2">
            <div className="list-group">
              {/* 在React中靠路由链接切换组件---编写路由链接 */}
              <NavLink className="list-group-item" to='/about'>About</NavLink>
              <NavLink className="list-group-item" to='/home'>home</NavLink>
            </div>
          </div>
          <div className="col-xs-6">
            <div className="panel">
              <div className="panel-body">
                <Suspense fallback={<Loading />}>
                  {/* 注册路由 */}
                  <Route path="/about" component={About}></Route>
                  <Route path="/home" component={Home}></Route>
                </Suspense>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }
}

