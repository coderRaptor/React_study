import React, { Component } from 'react'

export default class Home extends Component {
  render() {
    return (
      <h1>我是Home组件</h1>
    )
  }
}
