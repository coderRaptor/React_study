import React, { Component } from 'react'

export default class Loading extends Component {
  render() {
    return (
      <h2 style={{backgroundColor: 'grey', color:'pink'}}>Loading....</h2>
    )
  }
}
