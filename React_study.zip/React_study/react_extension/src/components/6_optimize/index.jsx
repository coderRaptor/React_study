import React, { PureComponent } from 'react'
import './index.css'
/* 
PureComponent重写了内部是更新阀门钩子
当组件的state或props里面的数据发生改变时会自动比较如果不同才返回true允许更新,重写调用render
带来的好处: 
        当父组件传给子组件的props或自身的state没有变化时,不会引起组件重新调用render, 提高效率
 */
export default class Parent extends PureComponent {
    state = { carName: '奔驰c63' }
    changeCar = () => {
        this.setState({ carName: '迈巴赫' })

        // 使用了PureComponent后一下代码失效
        // 因为它里面重写的更新阀门钩子是浅比较
        // 发现更新状态对象与原状态对象引用一致, 会认为数据并没有更新
        // 不但最外层是浅比较,里面是引用数据都是浅比较
        // 所以用了PureComponent后改变数据一定要用新引用值,例如 arr:[新数据, ...arr]
        // const obj = this.state;
        // obj.carName = '迈巴赫';
        // this.setState(obj)
    }
    render() {
        console.log("Parent---render")
        const { carName } = this.state
        return (
            <div className='parent'>
                <h3>我是Parent组件</h3>
                <span>我的车名字是:{carName}</span><br />
                <button onClick={this.changeCar}>点我换车</button>
                <Child carName="奥拓"/>
            </div>
        )
    }
}

class Child extends PureComponent {
  render() {
    console.log("Child---render")
    return (
      <div className='child'>
        <h3>我是Child组件</h3>
        <span>我从Parent组件中接收的车名是: {this.props.carName}</span>
      </div>
    )
  }
}

