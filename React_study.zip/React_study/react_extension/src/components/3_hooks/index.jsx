import React from 'react';
import ReactDOM from 'react-dom/client';

export default function Demo() {
    console.log('Demo')
    /* 
        可能你会想到,点击改变状态后React肯定会重新渲染组件,
        那么函数式组件想要重新渲染必须重新调用, 它不像类式组件调用实例的render就行
        那么重新调用函数组件useState就会重新调用, 不就又重新初始化了吗?
        函数组件确实会重新调用, 但是即便重新执行 useState 也不会重新初始化, 这时useState的调用传入的参数会被忽略
        因为 useState 底层已经考虑到了这个问题, 所以只有组件初次渲染时调用 useState 有效
    */
    const [count, setCount] = React.useState(0);
    const [name, setName] = React.useState('tom');


    /* 
        useEffect的使用解释太多,建议上官方文档
        https://react.docschina.org/reference/react/useEffect
    */

    const myRef = React.useRef()
    function show(){
        alert(myRef.current.value)
    }
    function unmount() {
        ReactDOM.unmountComponentAtNode(document.getElementById('root'))
    }
    function add() {
        // setCount(count+1) // 第一种写法
        setCount(count => count + 1)
    }
    function changeName() {
        setName('jack')
    }
    return (
        <div>
            <input type="text" ref={myRef} />
            <h2>当前求和为: {count}</h2>
            <h2>我的名字是: {name}</h2>
            <button onClick={add}>点我+1</button>
            <button onClick={changeName}>点我改名</button>
            <button onClick={show}>点我查看输入的数据</button>
            <button onClick={unmount}>卸载组件</button>
        </div>
    )
}
