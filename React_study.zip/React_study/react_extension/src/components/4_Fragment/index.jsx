import React, { Fragment } from 'react'

export default function Demo() {
    return (
        // 当你不想要根标签增添多余但是又被jsx必须有根标签语法限制时
        // Fragment就可以派出用场, 充当根标签并且React解析Fragment时会丢掉它,
        // Fragment组件标签不参与dom结构, 即解析后网页的dom结构没有它只有里面的子标签
        <Fragment>
            <Demo />
        </Fragment>
    )
}

/* function Demo1() {
    return (
        // 在React中的jsx里你也可以使用 空标签 代替根标签, 既不参与dom结构又避免了与jsx语法冲突
        <>
            <div>Demo1</div>
            <div>Demo1</div>
        </>
    )
} */
// 有区别的是Fragment可以接收 key 属性, 空标签不能接收任何属性
// 所以当你不想要根标签但是又想遍历输出里面的所有子标签时Fragment就派上用场了
// 如下
/* function Demo2() {
    const arr = [1,2,3]
  return (
    <>
        {
            arr.map((n) => {
                return (
                    <Fragment key={n}>
                        <div>Demo222</div>
                        <div>Demo222</div>
                    </Fragment>
                )
            })
        }
    </>
  )
} */