import React, { Component } from 'react'

export default class Demo extends Component {
    state = { count: 0 }
    add = () => {
        // const { count } = this.state;
        /*  this.setState({count:count + 1})
         // setState调用后引起React更新状态数据的操作是异步的, 所以调用setState后立即输出还是之前的值
         // 如果你想改变之后立即利用该值进行操作,可以在setState第二个参数传入回调函数(可选参数)
         // 这个回调是在React进行状态更新完毕并且重新render完毕后再调用的
         // 点击 + 1后 输出还是 0
         console.log(this.state.count) */

        // this.setState({count: count + 1}, () => {
        //     console.log(this.state.count)
        // })

        // 第一个参数对象式是函数式的一个简写方式, 如果状态数据改变不依赖原状态和props, 用简写方便
        // 上面的第一个参数是对象式的, 此外第一个参数还可以是函数式, 该函数必须返回一个 状态改变对象
        // 此外第一个参数是函数式还能接收到state和props两个参数
        // this.setState((state, props) => {
        //     console.log(state, props)
        //     console.log(222)
        //     return { count: state.count + 1 }
        // })
        // 当然你不需要props可以不接受
        this.setState(state => ({ count: state.count + 1 }))
    }
    render() {
        return (
            <div>
                <h1>当前求和为: {this.state.count}</h1>
                <button onClick={this.add}>点我 + 1</button>
            </div>
        )
    }
}
