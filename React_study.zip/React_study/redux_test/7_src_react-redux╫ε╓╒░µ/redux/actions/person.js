import { ADD_PERSON } from "../constant";

export const addPerson = data => ({type: ADD_PERSON, data})