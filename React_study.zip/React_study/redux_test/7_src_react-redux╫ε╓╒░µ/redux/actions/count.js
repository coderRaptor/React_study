/* 
    该文件专门为Count组件生成action对象
*/
import { INCREMENT, DECREMENT } from '../constant';

// 同步action, 指action的值为Object类型的普通对象
export const increment = data => ({ type: INCREMENT, data })
export const decrement = data => ({ type: DECREMENT, data })

// 异步action, 指action的值为函数,异步action中一般等一般任务有结果了再调用同步action
// 异步action不是必须要用的, 你完全可以再组件当中等异步任务结束了再调用同步action, 这里只不过是把异步的任务编码转移到了count_action.js中
// 所以了解有这种写法方式就可以了
export const incrementAsync = (data, delay) => {
    // 返回一个函数, store帮调用, 会传入其dispatch方法, 不需要再引入store了
    return (dispatch) => {
        setTimeout(() => {
            dispatch(increment(data))
        }, delay)
    }
}