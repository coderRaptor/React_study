// 引入汇总reducer的api
import { combineReducers } from 'redux';

// 引入为组件服务的reducer
import count from './count';
import persons from "./person";

export default combineReducers({
    count,
    persons
})