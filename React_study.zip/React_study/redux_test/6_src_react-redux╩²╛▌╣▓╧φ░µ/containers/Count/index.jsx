import React, { Component } from 'react';

// 引入action
import {
    createDecrementAction,
    createIncrementAction,
    createIncrementAsyncAction
} from '../../redux/actions/count';

// 引入connect用于连接UI组件与redux
import { connect } from 'react-redux';

// 创建UI组件
class Count extends Component {
    increment = () => {
        // console.log(this.props)
        const { value } = this.selectionElement;
        this.props.jia(value * 1)
        // this.forceUpdate()
    }
    decrement = () => {
        const { value } = this.selectionElement;
        this.props.jian(value * 1)
    }
    incrementIfOdd = () => {
        if (this.props.count % 2 === 0) return;
        const { value } = this.selectionElement;
        this.props.jia(value * 1)
    }
    incrementAsync = () => {
        const { value } = this.selectionElement;
        // setTimeout(() => {
        this.props.jiaAsync(value * 1, 1000)
        // }, 1000);
    }
    render() {
        return (
            <div>
                <h1>我是Count组件, 下方人数总和为: {this.props.personSum}</h1>
                <h2>当前求和为: {this.props.count}</h2>
                <select ref={c => this.selectionElement = c}>
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                </select>&nbsp;
                <button onClick={this.increment}>+</button>&nbsp;
                <button onClick={this.decrement}>-</button>&nbsp;
                <button onClick={this.incrementIfOdd}>当前求和为奇数再加</button>&nbsp;
                <button onClick={this.incrementAsync}>异步加</button>
            </div>
        )
    }
}

// 使用connect()()创建并暴露一个Count的容器组件
export default connect(
    state => ({ count: state.countReducer, personSum: state.personReducer.length }),
    // mapDispatchToProps一般写法
    /* dispatch => ({
        jia: number => dispatch(createIncrementAction(number)),
        jian: number => dispatch(createDecrementAction(number)),
        jiaAsync: (number, delay) => dispatch(createIncrementAsyncAction(number, delay)),
    }) */
    // mapDispatchToProps简写, react-redux底层源码自动dispatch传参调用
    // 这是上面的简写 
    {
        jia: createIncrementAction,
        jian: createDecrementAction,
        jiaAsync: createIncrementAsyncAction
    }
)(Count)