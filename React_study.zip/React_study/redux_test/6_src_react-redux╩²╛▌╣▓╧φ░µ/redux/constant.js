/* 
    该模块是用于定义action对象中的type类型的值,目的是便于管理,防止程序员疏忽写错
*/

export const INCREMENT = 'increment';
export const DECREMENT = 'decrement';

export const ADD_PERSON = 'add_person';