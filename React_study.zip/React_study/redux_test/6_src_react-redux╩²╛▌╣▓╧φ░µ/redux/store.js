/* 
    该文档专门用于暴露一个store对象, 整个应用只有一个store对象
*/

// legacy_createStore, 专门用于创建redux中最为核心的store对象
import { legacy_createStore, applyMiddleware, combineReducers } from "redux";
// 引入thunk, 用于支持异步action
import thunk from 'redux-thunk';

// 引入为组件服务的reducer
import countReducer from './reducers/count';
import personReducer from "./reducers/person";

// 引入redux-devtools-extension
import { composeWithDevTools } from "redux-devtools-extension";

const combineState = combineReducers({
    countReducer,
    personReducer
})
export default legacy_createStore(combineState, composeWithDevTools(applyMiddleware(thunk)));