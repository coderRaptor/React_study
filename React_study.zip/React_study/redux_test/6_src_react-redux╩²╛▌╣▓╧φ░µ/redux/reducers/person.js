import { ADD_PERSON } from "../constant";

const init = [{id:'001', name:'张三', age: 23}]
export default function personReducer(preState=init, action){
    const {type, data} = action;
    switch (type) {
        case ADD_PERSON:
            // 不可以像注释一样写,因为redux底层比较的是返回值,
            // 这样写虽然preState是改了, 但是返回数组的引用没变, redux 会误以为返回值是一致的从而导致不更新组件, 即失去数据响应式
            /* preState.unshift(data)
            return preState; */

            // 返回一个新数组, 没有改写preState
            // 也正因如此, redux 的 reducer 必须是一个纯函数
            return [data, ...preState];
        default:
            return preState;
    }
}

// 纯函数
/* 
    必须遵守一下一些约束:
        1.不得改写参数数据
        2.不会产生任何副作用, 例如网络请求, 输入和输出设备
        3.不能调用 Date.now() 或者 Math.random() 等不纯的方法
*/
// redux 的 reducer 必须是一个纯函数
// 所以下面这个不能写,因为改写了参数数据preState
/* preState.unshift(data)
return preState; */
