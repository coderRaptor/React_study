import { ADD_PERSON } from "../constant";

export const createPersonAction = data => ({type: ADD_PERSON, data})