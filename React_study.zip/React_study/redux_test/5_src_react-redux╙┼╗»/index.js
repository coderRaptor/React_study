import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import store from './redux/store';
import { Provider } from 'react-redux';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    {/* Provider 可以检测App组件子组件及后代组件的容器组件, 并给这些容器组件传入在Provider组件标签传入的属性 */}
    {/* 这样就不用在每个容器组件上都一个个地传入store了 */}
    <Provider store={store}>
      <App />
    </Provider>
  </React.StrictMode>
);

// react-redux底层connect返回的容器组件能够监测状态改变并使得react更新组件
// 所以使用了react-redux就不用下面这些了

// 检测redux中状态的改变，若redux的状态发生了改变，那么重新渲染App组件
// store.subscribe(() => {
//   root.render(
//     <React.StrictMode>
//       <App />
//     </React.StrictMode>
//   );
// })

