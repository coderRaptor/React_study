import React, { useState } from 'react'
import { Navigate } from 'react-router-dom'

export default function Home() {
  const [sum, setSum] = useState(1)
  return (
    <>
      <h2>我是Home组件</h2>
      {sum === 2 ? <Navigate to="/about" replace /> : <h4>当前sum的值为: {sum}</h4> }
      <button onClick={()=>setSum(2)}>点我将sum的值变为2</button>
    </>

  )
}
