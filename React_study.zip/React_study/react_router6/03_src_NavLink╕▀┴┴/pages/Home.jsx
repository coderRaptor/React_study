export default function Home() {
  return (
    <>
      <h2>我是Home组件</h2>
    </>
  )
}
