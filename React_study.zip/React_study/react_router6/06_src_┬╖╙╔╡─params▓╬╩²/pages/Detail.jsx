import React from 'react'
import { useMatch, useParams } from 'react-router-dom'

export default function Detail(props) {
  console.log('props==>',props)
  const {id, title, content} = useParams() // 常用
  const x = useMatch('/home/message/detail/:id/:title/:content') // 不常用
  console.log('x==>', x)
  return (
    <ul>
        <li>消息编号: {id}</li>
        <li>消息标题: {title}</li>
        <li>消息内容: {content}</li>
    </ul>
  )
}
