import {NavLink, Outlet, useOutlet} from 'react-router-dom'

export default function Home() {
  /* 
    如果该组件的嵌套路由没有挂载, 则result为null
    如果该组件的嵌套路由已经挂载, 则result为嵌套路由对象

    这里Home组件设置了默认挂载其嵌套路由 News, 所以 result 是 News 组件实例
  */
 const result = useOutlet()
  console.log(result)
  return (
    <>
      <h2>Home组件内容</h2>
      <div>
        <ul className="nav nav-tabs">
          <li>
            <NavLink className="list-group-item" replace to="news">News</NavLink>
          </li>
          <li>
            <NavLink className="list-group-item" to="message">Message</NavLink>
          </li>
        </ul>
        <Outlet/>
      </div>
    </>
  )
}
