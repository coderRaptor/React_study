import React from 'react'
import { useNavigationType } from 'react-router-dom'

export default function News() {
  // 检测该路由组件是通过什么导航方式呈现的 push replace pop
  // pop是指直接输入url到达这个组件, 刷新也算
  console.log(useNavigationType())
  return (
    <ul>
      <li>news001</li>
      <li>news002</li>
      <li>news003</li>
    </ul>
  )
}
