import React, { useState } from 'react'
import { Link, Outlet, useNavigate } from 'react-router-dom'

export default function Message() {
    const navigate = useNavigate()
    const [message] = useState([
        { id: '001', title: '消息1', content: '锄禾日当午' },
        { id: '002', title: '消息2', content: '汗滴禾下土' },
        { id: '003', title: '消息3', content: '谁知盘中餐' },
        { id: '004', title: '消息4', content: '粒粒皆辛苦' },
    ])
    function showDetail(m) {
        // 编程式路由导航, 过0.5s后跳转
        setTimeout(() => {
            navigate('detail', {
                replace:false,// 不写默认也是false, 即为 push
                state:{ // 只能写state参数, 如果想用params或search请拼接在navigate的第一个参数路径中
                    id: m.id,
                    title: m.title,
                    content: m.content
                }
            })
        }, 500)
    }
    return (
        <div>
            <ul>
                {
                    message.map((m) => {
                        return (
                        <li key={m.id}>
                            <Link 
                            to="detail" 
                            state={{
                                id:m.id,
                                title: m.title,
                                content: m.content
                            }}
                            >{m.title}</Link>
                            <button onClick={()=>showDetail(m)}>查看详情</button>
                        </li>
                        )
                    })
                }
            </ul>
            <hr />
            {/* 子级路由展示的位置 */}
            <Outlet />
        </div>
    )
}
