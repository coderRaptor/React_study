import React from 'react'
import { useResolvedPath } from 'react-router-dom'

export default function News() {
  // 把url字符串作为参数,解析并拆分信息
  // @@ {pathname: '/user', search: '?id=001&name=tom', hash: ''}
  console.log('@@', useResolvedPath('/user?id=001&name=tom'))
  return (
    <ul>
      <li>news001</li>
      <li>news002</li>
      <li>news003</li>
    </ul>
  )
}
