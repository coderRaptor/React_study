import React from 'react'
import { useInRouterContext } from 'react-router-dom'

export default function Demo() {
  // 是否在路由上下文环境中, 只要被BrowserRouter包裹就是处于路由器上下文环境
  // 即App组件及其后代组件都处于路由器上下文环境
  // 而这里的Demo故意写在BrowserRouter外边, 用于测试
  const isInRouterContext = useInRouterContext()
  console.log("Demo是否处于路由器上下文中", isInRouterContext)// false
  return (
    <div>Demo</div>
  )
}
