import React from 'react'
import { useNavigate } from 'react-router-dom'

export default function Header() {
    const navigate = useNavigate()
    function goback(){
        navigate(-1)
    }
    function goforward(){
        navigate(1)
    }
    return (
        <div className="page-header">
            <h2>React Router Demo</h2>
            <button onClick={goforward}>⋘后退</button>
            <button onClick={goback}>前进⋙</button>
        </div>
    )
}
